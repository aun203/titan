from linepy import *
import sys, codecs, json, random, time

APP = "DESKTOPMAC\t10.10.2-YOSEMITE-x64\tMAC 4.5.0"

def loadFile(filename):
    try:
        loadedLoad = open(filename)
        loaded = loadedLoad.readline()
    except:
        f = open(filename, 'a+')
        f.write('#')
        f.close()
        loadedLoad = open(filename)
        loaded = loadedLoad.read()
        loadedLoad.close()
    return loaded

def saveFile(filename, data):
    loadedLoad = open(filename, 'w')
    loadedLoad.write(data)
    loadedLoad.close()

helpMessage = """----------- จัดการคิก -----------
- titan:inv เชิญคิก
- titan:join เรียกคิก
- titan:bye สั่งคิกออก
- titan:kick (@) เตะคนที่แท็ก
- titan:clearban ล้างบัญชีดำ
- titan:check ดูว่าบอทอยู่หรือไม่
- titan:speed ตรวจสอบความเร็ว
- titan:name [ชื่อใหม่] เปลี่ยนชื่อ

----------- ป้องกัน -----------
- /bword [คำ] เพิ่มคำต้องห้าม
- /bword ดูคำต้องห้ามทั้งหมด
* ป้องกันแยกกลุ่ม
- /pkick on/off เปิด/ปิด ป้องกันเตะ
- /pinv on/off เปิด/ปิด ป้องกันเชิญ
- /pset ตรวจสอบการป้องกัน"""

clientToken = loadFile("cl.token")
try:
    client = LINE(clientToken, appName=APP)
except:
    client = LINE(appName=APP)
saveFile("cl.token",client.authToken)

titan1Token = loadFile("t1.token")
try:
    titan1 = LINE(titan1Token, appName=APP)
except:
    titan1 = LINE(appName=APP)
saveFile("t1.token",titan1.authToken)

titan2Token = loadFile("t2.token")
try:
    titan2 = LINE(titan2Token, appName=APP)
except:
    titan2 = LINE(appName=APP)
saveFile("t2.token",titan2.authToken)

titan3Token = loadFile("t3.token")
try:
    titan3 = LINE(titan3Token, appName=APP)
except:
    titan3 = LINE(appName=APP)
saveFile("t3.token",titan3.authToken)

titan4Token = loadFile("t4.token")
try:
    titan4 = LINE(titan4Token, appName=APP)
except:
    titan4 = LINE(appName=APP)
saveFile("t4.token",titan4.authToken)

titan5Token = loadFile("t5.token")
try:
    titan5 = LINE(titan5Token, appName=APP)
except:
    titan5 = LINE(appName=APP)
saveFile("t5.token",titan5.authToken)

clientMid = client.profile.mid
titan1Mid = titan1.profile.mid
titan2Mid = titan2.profile.mid
titan3Mid = titan3.profile.mid
titan4Mid = titan4.profile.mid
titan5Mid = titan5.profile.mid
titanMid = [clientMid,titan1Mid,titan2Mid,titan3Mid,titan4Mid,titan5Mid]
titanMidWithoutClientMid = [titan1Mid,titan2Mid,titan3Mid,titan4Mid,titan5Mid]
fuckingShit = [titan1,titan2,titan3,titan4,titan5,client]

client.findAndAddContactsByMid(titan1Mid)
client.findAndAddContactsByMid(titan2Mid)
client.findAndAddContactsByMid(titan3Mid)
client.findAndAddContactsByMid(titan4Mid)
client.findAndAddContactsByMid(titan5Mid)

titan2.findAndAddContactsByMid(titan1Mid)
titan3.findAndAddContactsByMid(titan1Mid)
titan4.findAndAddContactsByMid(titan1Mid)
titan5.findAndAddContactsByMid(titan1Mid)

titan1.findAndAddContactsByMid(titan2Mid)
titan3.findAndAddContactsByMid(titan2Mid)
titan4.findAndAddContactsByMid(titan2Mid)
titan5.findAndAddContactsByMid(titan2Mid)

titan1.findAndAddContactsByMid(titan3Mid)
titan2.findAndAddContactsByMid(titan3Mid)
titan4.findAndAddContactsByMid(titan3Mid)
titan5.findAndAddContactsByMid(titan3Mid)

titan1.findAndAddContactsByMid(titan4Mid)
titan2.findAndAddContactsByMid(titan4Mid)
titan3.findAndAddContactsByMid(titan4Mid)
titan5.findAndAddContactsByMid(titan4Mid)

titan1.findAndAddContactsByMid(titan5Mid)
titan2.findAndAddContactsByMid(titan5Mid)
titan3.findAndAddContactsByMid(titan5Mid)
titan4.findAndAddContactsByMid(titan5Mid)

Poll = OEPoll(client)

try:
    titanLoad = codecs.open("titan.json","r","utf-8")
    titan = json.load(titanLoad)
except:
    f = open("titan.json", "a+")
    f.write('{"blacklist":{},"bword":{}}')
    f.close()
    titanLoad = codecs.open("titan.json","r","utf-8")
    titan = json.load(titanLoad)

def titanBot(op):
    try:
        if op.type == 13:
            if "pinv" not in titan:
                titan["pinv"] = {}
            if op.param1 in titan["pinv"] and op.param2 not in titanMid:
                titan["blacklist"][op.param2] = True
                titan["blacklist"][op.param3] = True
                try:
                    titan4.cancelGroupInvitation(op.param1, [op.param3])
                except:
                    titan5.cancelGroupInvitation(op.param1, [op.param3])
                try:
                    titan5.kickoutFromGroup(op.param1, [op.param2])
                except:
                    titan4.kickoutFromGroup(op.param1, [op.param2])
            if op.param2 in titan["blacklist"] or op.param3 in titan["blacklist"]:
                if op.param2 in titanMid or op.param3 in titanMid:
                    return
                titan["blacklist"][op.param2] = True
                titan["blacklist"][op.param3] = True
                try:
                    titan3.cancelGroupInvitation(op.param1, [op.param3])
                    titan3.kickoutFromGroup(op.param1, [op.param2])
                except:
                    try:
                        titan2.cancelGroupInvitation(op.param1, [op.param3])
                        titan2.kickoutFromGroup(op.param1, [op.param2])
                    except:
                        try:
                            titan1.cancelGroupInvitation(op.param1, [op.param3])
                            titan1.kickoutFromGroup(op.param1, [op.param2])
                        except:
                            try:
                                titan4.cancelGroupInvitation(op.param1, [op.param3])
                                titan4.kickoutFromGroup(op.param1, [op.param2])
                            except:
                                try:
                                    titan5.cancelGroupInvitation(op.param1, [op.param3])
                                    titan5.kickoutFromGroup(op.param1, [op.param2])
                                except:
                                    pass
                for mid in titan["blacklist"]:
                    try:
                        titan3.cancelGroupInvitation(op.param1, [mid])
                        titan3.kickoutFromGroup(op.param1, [mid])
                    except:
                        try:
                            titan2.cancelGroupInvitation(op.param1, [mid])
                            titan2.kickoutFromGroup(op.param1, [mid])
                        except:
                            try:
                                titan1.cancelGroupInvitation(op.param1, [mid])
                                titan1.kickoutFromGroup(op.param1, [mid])
                            except:
                                try:
                                    titan4.cancelGroupInvitation(op.param1, [mid])
                                    titan4.kickoutFromGroup(op.param1, [mid])
                                except:
                                    try:
                                        titan5.cancelGroupInvitation(op.param1, [mid])
                                        titan5.kickoutFromGroup(op.param1, [mid])
                                    except:
                                        pass
        if op.type == 17:
            if op.param2 in titan["blacklist"] and op.param2 not in titanMid:
                titan["blacklist"][op.param2] = True
                try:
                    titan3.kickoutFromGroup(op.param1, [op.param2])
                except:
                    try:
                        titan2.kickoutFromGroup(op.param1, [op.param2])
                    except:
                        try:
                            titan1.kickoutFromGroup(op.param1, [op.param2])
                        except:
                            try:
                                titan4.kickoutFromGroup(op.param1, [op.param2])
                            except:
                                try:
                                    titan5.kickoutFromGroup(op.param1, [op.param2])
                                except:
                                    pass
                for mid in titan["blacklist"]:
                    try:
                        titan3.kickoutFromGroup(op.param1, [mid])
                    except:
                        try:
                            titan2.kickoutFromGroup(op.param1, [mid])
                        except:
                            try:
                                titan1.kickoutFromGroup(op.param1, [mid])
                            except:
                                try:
                                    titan4.kickoutFromGroup(op.param1, [mid])
                                except:
                                    try:
                                        titan5.kickoutFromGroup(op.param1, [mid])
                                    except:
                                        pass
        if op.type == 19:
            if "pkick" not in titan:
                titan["pkick"] = {}
            if op.param1 in titan["pkick"] and op.param2 not in titanMid:
                titan["blacklist"][op.param2] = True
                try:
                    titan5.kickoutFromGroup(op.param1, [op.param2])
                except:
                    titan4.kickoutFromGroup(op.param1, [op.param2])
            if op.param3 in titanMid:
                titan["blacklist"][op.param2] = True
                if op.param3 in titanMidWithoutClientMid and op.param2 not in titanMid:
                    try:
                        group = client.getGroup(op.param1)
                        groupMemberMids = [i.mid for i in group.members if i.mid in titanMid]
                        titanBlackList = [i.mid for i in group.members if i.mid in titan["blacklist"]]
                        notInGroup = []
                        if titan5Mid not in groupMemberMids:
                            notInGroup.append(titan5Mid)
                        if titan4Mid not in groupMemberMids:
                            notInGroup.append(titan4Mid)
                        if titan3Mid not in groupMemberMids:
                            notInGroup.append(titan3Mid)
                        if titan2Mid not in groupMemberMids:
                            notInGroup.append(titan2Mid)
                        if titan1Mid not in groupMemberMids:
                            notInGroup.append(titan1Mid)
                        if notInGroup != []:
                            if titan1Mid in groupMemberMids:
                                try:
                                    titan1.inviteIntoGroup(group.id, notInGroup)
                                except:
                                    if titan2Mid in groupMemberMids:
                                        try:
                                            titan2.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan3Mid in groupMemberMids:
                                                try:
                                                    titan3.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    if titan4Mid in groupMemberMids:
                                                        try:
                                                            titan4.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                    elif titan5Mid in groupMemberMids:
                                                        try:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            pass
                                            elif titan4Mid in groupMemberMids:
                                                try:
                                                    titan4.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                            elif titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan3Mid in groupMemberMids:
                                        try:
                                            titan3.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan4Mid in groupMemberMids:
                                                try:
                                                    titan4.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    if titan5Mid in groupMemberMids:
                                                        try:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            pass
                                            elif titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan4Mid in groupMemberMids:
                                        try:
                                            titan4.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan5Mid in groupMemberMids:
                                        try:
                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            pass
                            elif titan2Mid in groupMemberMids:
                                try:
                                    titan2.inviteIntoGroup(group.id, notInGroup)
                                except:
                                    if titan1Mid in groupMemberMids:
                                        try:
                                            titan1.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan3Mid in groupMemberMids:
                                                try:
                                                    titan3.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    if titan4Mid in groupMemberMids:
                                                        try:
                                                            titan4.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                    elif titan5Mid in groupMemberMids:
                                                        try:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            pass
                                            elif titan4Mid in groupMemberMids:
                                                try:
                                                    titan4.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                            elif titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan3Mid in groupMemberMids:
                                        try:
                                            titan3.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan4Mid in groupMemberMids:
                                                try:
                                                    titan4.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    if titan5Mid in groupMemberMids:
                                                        try:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            pass
                                            elif titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan4Mid in groupMemberMids:
                                        try:
                                            titan4.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan5Mid in groupMemberMids:
                                        try:
                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            pass
                            elif titan3Mid in groupMemberMids:
                                try:
                                    titan3.inviteIntoGroup(group.id, notInGroup)
                                except:
                                    if titan2Mid in groupMemberMids:
                                        try:
                                            titan2.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan3Mid in groupMemberMids:
                                                try:
                                                    titan3.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    if titan4Mid in groupMemberMids:
                                                        try:
                                                            titan4.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                    elif titan5Mid in groupMemberMids:
                                                        try:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            pass
                                            elif titan4Mid in groupMemberMids:
                                                try:
                                                    titan4.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                            elif titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan3Mid in groupMemberMids:
                                        try:
                                            titan3.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan4Mid in groupMemberMids:
                                                try:
                                                    titan4.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    if titan5Mid in groupMemberMids:
                                                        try:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            pass
                                            elif titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan4Mid in groupMemberMids:
                                        try:
                                            titan4.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan5Mid in groupMemberMids:
                                        try:
                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            pass
                            elif titan4Mid in groupMemberMids:
                                try:
                                    titan4.inviteIntoGroup(group.id, notInGroup)
                                except:
                                    if titan2Mid in groupMemberMids:
                                        try:
                                            titan2.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan3Mid in groupMemberMids:
                                                try:
                                                    titan3.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    if titan4Mid in groupMemberMids:
                                                        try:
                                                            titan4.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                    elif titan5Mid in groupMemberMids:
                                                        try:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            pass
                                            elif titan4Mid in groupMemberMids:
                                                try:
                                                    titan4.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                            elif titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan3Mid in groupMemberMids:
                                        try:
                                            titan3.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan4Mid in groupMemberMids:
                                                try:
                                                    titan4.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    if titan5Mid in groupMemberMids:
                                                        try:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            pass
                                            elif titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan4Mid in groupMemberMids:
                                        try:
                                            titan4.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan5Mid in groupMemberMids:
                                        try:
                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            pass
                            elif titan5Mid in groupMemberMids:
                                try:
                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                except:
                                    if titan2Mid in groupMemberMids:
                                        try:
                                            titan2.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan3Mid in groupMemberMids:
                                                try:
                                                    titan3.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    if titan4Mid in groupMemberMids:
                                                        try:
                                                            titan4.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                    elif titan5Mid in groupMemberMids:
                                                        try:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            pass
                                            elif titan4Mid in groupMemberMids:
                                                try:
                                                    titan4.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                            elif titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan3Mid in groupMemberMids:
                                        try:
                                            titan3.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan4Mid in groupMemberMids:
                                                try:
                                                    titan4.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    if titan5Mid in groupMemberMids:
                                                        try:
                                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                                        except:
                                                            pass
                                            elif titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan4Mid in groupMemberMids:
                                        try:
                                            titan4.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan5Mid in groupMemberMids:
                                                try:
                                                    titan5.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan5Mid in groupMemberMids:
                                        try:
                                            titan5.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            pass
                        for mid in titanBlackList:
                            try:
                                titan3.kickoutFromGroup(op.param1, [mid])
                            except:
                                try:
                                    titan2.kickoutFromGroup(op.param1, [mid])
                                except:
                                    try:
                                        titan1.kickoutFromGroup(op.param1, [mid])
                                    except:
                                        try:
                                            titan4.kickoutFromGroup(op.param1, [mid])
                                        except:
                                            try:
                                                titan5.kickoutFromGroup(op.param1, [mid])
                                            except:
                                                pass
                        if titan3Mid not in groupMemberMids:
                            titan3.acceptGroupInvitation(op.param1)
                        if titan2Mid not in groupMemberMids:
                            titan2.acceptGroupInvitation(op.param1)
                        if titan1Mid not in groupMemberMids:
                            titan1.acceptGroupInvitation(op.param1)
                        if titan4Mid not in groupMemberMids:
                            titan4.acceptGroupInvitation(op.param1)
                        if titan5Mid not in groupMemberMids:
                            titan5.acceptGroupInvitation(op.param1)
                    except Exception as Error:
                        print(Error)
                elif clientMid in op.param3:
                    try:
                        try:
                            group = titan1.getGroup(op.param1)
                        except:
                            try:
                                group = titan2.getGroup(op.param1)
                            except:
                                group = titan3.getGroup(op.param1)
                        groupMemberMids = [i.mid for i in group.members if i.mid in titanMid]
                        titanBlackList = [i.mid for i in group.members if i.mid in titan["blacklist"]]
                        notInGroup = []
                        if titan3Mid not in groupMemberMids:
                            notInGroup.append(titan3Mid)
                        if titan2Mid not in groupMemberMids:
                            notInGroup.append(titan2Mid)
                        if titan1Mid not in groupMemberMids:
                            notInGroup.append(titan1Mid)
                        if clientMid not in groupMemberMids:
                            notInGroup.append(clientMid)
                        if notInGroup != []:
                            if titan1Mid in groupMemberMids:
                                try:
                                    titan1.inviteIntoGroup(group.id, notInGroup)
                                except:
                                    if titan2Mid in groupMemberMids:
                                        try:
                                            titan2.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan3Mid in groupMemberMids:
                                                try:
                                                    titan3.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan3Mid in groupMemberMids:
                                        try:
                                            titan3.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            pass
                            elif titan2Mid in groupMemberMids:
                                try:
                                    titan2.inviteIntoGroup(group.id, notInGroup)
                                except:
                                    if titan1Mid in groupMemberMids:
                                        try:
                                            titan1.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan3Mid in groupMemberMids:
                                                try:
                                                    titan3.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan3Mid in groupMemberMids:
                                        try:
                                            titan3.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            pass
                            elif titan3Mid in groupMemberMids:
                                try:
                                    titan3.inviteIntoGroup(group.id, notInGroup)
                                except:
                                    if titan1Mid in groupMemberMids:
                                        try:
                                            titan1.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            if titan2Mid in groupMemberMids:
                                                try:
                                                    titan2.inviteIntoGroup(group.id, notInGroup)
                                                except:
                                                    pass
                                    elif titan2Mid in groupMemberMids:
                                        try:
                                            titan2.inviteIntoGroup(group.id, notInGroup)
                                        except:
                                            pass
                        for mid in titanBlackList:
                            try:
                                titan3.kickoutFromGroup(op.param1, [mid])
                            except:
                                try:
                                    titan2.kickoutFromGroup(op.param1, [mid])
                                except:
                                    try:
                                        titan1.kickoutFromGroup(op.param1, [mid])
                                    except:
                                        try:
                                            titan4.kickoutFromGroup(op.param1, [mid])
                                        except:
                                            try:
                                                titan5.kickoutFromGroup(op.param1, [mid])
                                            except:
                                                pass
                        if titan3Mid not in groupMemberMids:
                            titan3.acceptGroupInvitation(op.param1)
                        if titan2Mid not in groupMemberMids:
                            titan2.acceptGroupInvitation(op.param1)
                        if titan1Mid not in groupMemberMids:
                            titan1.acceptGroupInvitation(op.param1)
                        if clientMid not in groupMemberMids:
                            client.acceptGroupInvitation(op.param1)
                        if titan4Mid not in groupMemberMids:
                            titan4.acceptGroupInvitation(op.param1)
                        if titan5Mid not in groupMemberMids:
                            titan5.acceptGroupInvitation(op.param1)
                    except Exception as Error:
                        print(Error)

        if op.type == 11:
            if op.param2 in titan["blacklist"] and op.param2 not in titanMid:
                titan["blacklist"][op.param2] = True
                try:
                    titan3.kickoutFromGroup(op.param1, [op.param2])
                except:
                    try:
                        titan2.kickoutFromGroup(op.param1, [op.param2])
                    except:
                        try:
                            titan1.kickoutFromGroup(op.param1, [op.param2])
                        except:
                            pass
                for mid in titan["blacklist"]:
                    try:
                        titan3.kickoutFromGroup(op.param1, [mid])
                    except:
                        try:
                            titan2.kickoutFromGroup(op.param1, [mid])
                        except:
                            try:
                                titan1.kickoutFromGroup(op.param1, [mid])
                            except:
                                pass
        if op.type == 26:
            msg = op.message
            if msg.text is None:
                return
            if msg.text.lower() in titan["bword"]:
                if msg.toType == 2:
                    client.kickoutFromGroup(msg.to, [msg._from])
        if op.type == 25:
            msg = op.message
            if msg.text is None:
                return
            elif msg.text.lower() == "/bword":
                co = 0
                txt = "คำต้องห้ามทั้งหมด:"
                for i in titan["bword"]:
                    co = co + 1
                    txt+="\n{}. ".format(co) + i
                client.sendMessage(msg.to, txt)
            elif msg.text.lower().startswith("/bword"):
                cx = msg.text.split(" ")
                if cx[0] != "/bword":
                    return
                cc = msg.text.replace(cx[0] + " ", "")
                titan["bword"][cc] = True
                client.sendMessage(msg.to, "เพิ่ม '"+co+"' เข้าคำต้องห้ามแล้ว")
            elif msg.text.lower() == "/help":
                client.sendMessage(msg.to, helpMessage)
            elif msg.text.lower() in ["titan:clearban","ล้างหำ"]:
                if titan["blacklist"] == {}:
                    titan1.sendMessage(msg.to, "Not in blacklist.")
                    titan2.sendMessage(msg.to, "Not in blacklist.")
                    titan3.sendMessage(msg.to, "Not in blacklist.")
                    titan4.sendMessage(msg.to, "Not in blacklist.")
                    return titan5.sendMessage(msg.to, "Not in blacklist.")
                titan["blacklist"] = {}
                titan1.sendMessage(msg.to, "Success!")
                titan2.sendMessage(msg.to, "Success!")
                titan3.sendMessage(msg.to, "Success!")
                titan4.sendMessage(msg.to, "Success!")
                titan5.sendMessage(msg.to, "Success!")
            elif msg.text.lower().startswith("titan:banlist") or msg.text.lower().startswith("ดูหำ"):
                if msg.toType != 2: return client.sendMessage(msg.to, "Group only.")
                titanList = [titan1,titan2,titan3,titan4,titan5]
                for i in titan["blacklist"]:
                    random.choice(titanList).sendContact(msg.to, i)
            elif msg.text.lower().startswith("titan:ban") or msg.text.lower().startswith("ยัดหำ"):
                if msg.toType != 2: return client.sendMessage(msg.to, "Group only.")
                group = client.getGroup(msg.to)
                key = eval(msg.contentMetadata["MENTION"])
                tMid = [i["M"] for i in key["MENTIONEES"]]
                for i in tMid:
                    titan["blacklist"][i] = True
                titan1.sendMessage(msg.to, "Success!")
                titan2.sendMessage(msg.to, "Success!")
                titan3.sendMessage(msg.to, "Success!")
                titan4.sendMessage(msg.to, "Success!")
                titan5.sendMessage(msg.to, "Success!")
            elif msg.text.lower().startswith("titan:kick"):
                if msg.toType != 2: return client.sendMessage(msg.to, "Group only.")
                group = client.getGroup(msg.to)
                key = eval(msg.contentMetadata["MENTION"])
                tMid = [i["M"] for i in key["MENTIONEES"]]
                for i in tMid:
                    titan["blacklist"][i] = True
                for i in tMid:
                    titan5.kickoutFromGroup(msg.to, [i])
            elif msg.text.lower().startswith("titan:kickinv"):
                if msg.toType != 2: return client.sendMessage(msg.to, "Group only.")
                group = client.getGroup(msg.to)
                key = eval(msg.contentMetadata["MENTION"])
                tMid = [i["M"] for i in key["MENTIONEES"]]
                for i in tMid:
                    titan3.kickoutFromGroup(msg.to, [i])
                    titan3.inviteIntoGroup(msg.to, [i])
            elif msg.text.lower() in ["titan:kickban","เตะหำ"]:
                if msg.toType != 2: return client.sendMessage(msg.to, "Group only.")
                group = client.getGroup(msg.to)
                groupMemberMids = [i.mid for i in group.members if i.mid in titanMid]
                groupMemberMids = [i.mid for i in group.members if i.mid in titan["blacklist"]]
                if groupMemberMids == []:
                    titan1.sendMessage(msg.to, "Not in blacklist.")
                    titan2.sendMessage(msg.to, "Not in blacklist.")
                    titan3.sendMessage(msg.to, "Not in blacklist.")
                    titan4.sendMessage(msg.to, "Not in blacklist.")
                    return titan5.sendMessage(msg.to, "Not in blacklist.")
                for i in groupMemberMids:
                    titan3.kickoutFromGroup(msg.to, [i])
            elif msg.text.lower() in ["titan:bye","ไปหำ"]:
                if msg.toType != 2: return client.sendMessage(msg.to, "Group only.")
                group = client.getGroup(msg.to)
                groupMemberMids = [i.mid for i in group.members if i.mid in titanMid]
                if titan3Mid in groupMemberMids:
                    titan3.leaveGroup(group.id)
                if titan2Mid in groupMemberMids:
                    titan2.leaveGroup(group.id)
                if titan1Mid in groupMemberMids:
                    titan1.leaveGroup(group.id)
                if titan4Mid in groupMemberMids:
                    titan4.leaveGroup(group.id)
                if titan5Mid in groupMemberMids:
                    titan5.leaveGroup(group.id)
            elif msg.text.lower().startswith("titan:name"):
                fuck = msg.text.replace(msg.text.split(" ")[0]+" ","")
                prof = [titan1,titan5,titan2,titan3,titan4]
                for i in prof:
                    proy = i.getProfile()
                    proy.displayName = fuck
                    i.updateProfile(proy)
            elif msg.text.lower() in ["titan:speed","หำเร็ว"]:
                fuck = msg.text.replace(msg.text.split(" ")[0]+" ","")
                prof = [titan1,titan2,titan3,titan4,titan5]
                for i in prof:
                    startSpeed = time.time()
                    proy = i.getProfile()
                    endSpeed = time.time() - startSpeed
                    i.sendMessage(msg.to, str(endSpeed)[:6] + " วินาที\n" + str(endSpeed*1000).split(".")[0] + " ms")
            elif msg.text.lower() in ["titan:join","มาหำ"]:
                if msg.toType != 2: return client.sendMessage(msg.to, "Group only.")
                group = client.getGroup(msg.to)
                IC = False
                groupMemberMids = [i.mid for i in group.members if i.mid in titanMid]
                titanBlackList = [i.mid for i in group.members if i.mid in titan["blacklist"]]
                notInGroup = []
                if titan3Mid not in groupMemberMids:
                    notInGroup.append(titan3Mid)
                if titan2Mid not in groupMemberMids:
                    notInGroup.append(titan2Mid)
                if titan1Mid not in groupMemberMids:
                    notInGroup.append(titan1Mid)
                if titan4Mid not in groupMemberMids:
                    notInGroup.append(titan4Mid)
                if titan5Mid not in groupMemberMids:
                    notInGroup.append(titan5Mid)
                if notInGroup != []:
                    if group.preventedJoinByTicket == True:
                        IC = True
                        group.preventedJoinByTicket = False
                        client.updateGroup(group)
                    ticket = client.reissueGroupTicket(group.id)
                    if titan3Mid not in groupMemberMids:
                        titan3.acceptGroupInvitationByTicket(group.id,ticket)
                    if titan2Mid not in groupMemberMids:
                        titan2.acceptGroupInvitationByTicket(group.id,ticket)
                    if titan1Mid not in groupMemberMids:
                        titan1.acceptGroupInvitationByTicket(group.id,ticket)
                    if titan4Mid not in groupMemberMids:
                        titan4.acceptGroupInvitationByTicket(group.id,ticket)
                    if titan5Mid not in groupMemberMids:
                        titan5.acceptGroupInvitationByTicket(group.id,ticket)
                    if IC == True:
                        group.preventedJoinByTicket = True
                        client.updateGroup(group)
                else:
                    titan1.sendMessage(group.id, "Already in group.")
                    titan2.sendMessage(group.id, "Already in group.")
                    titan3.sendMessage(group.id, "Already in group.")
                    titan4.sendMessage(group.id, "Already in group.")
                    return titan5.sendMessage(group.id, "Already in group.")
            elif msg.text.lower() in ["titan:check","หำน้อย"]:
                if msg.toType != 2: return client.sendMessage(msg.to, "Group only.")
                group = client.getGroup(msg.to)
                groupMemberMids = [i.mid for i in group.members if i.mid in titanMid]
                if titan5Mid in groupMemberMids:
                    titan5.sendMessage(group.id, titan5.profile.displayName)
                if titan4Mid in groupMemberMids:
                    titan4.sendMessage(group.id, titan4.profile.displayName)
                if titan3Mid in groupMemberMids:
                    titan3.sendMessage(group.id, titan3.profile.displayName)
                if titan2Mid in groupMemberMids:
                    titan2.sendMessage(group.id, titan2.profile.displayName)
                if titan1Mid in groupMemberMids:
                    titan1.sendMessage(group.id, titan1.profile.displayName)
            elif msg.text.lower() in ["titan:inv","หำมา"]:
                if msg.toType != 2: return client.sendMessage(msg.to, "Group only.")
                group = client.getGroup(msg.to)
                groupMemberMids = [i.mid for i in group.members if i.mid in titanMid]
                titanBlackList = [i.mid for i in group.members if i.mid in titan["blacklist"]]
                notInGroup = []
                if titan5Mid not in groupMemberMids:
                    notInGroup.append(titan5Mid)
                if titan4Mid not in groupMemberMids:
                    notInGroup.append(titan4Mid)
                if titan3Mid not in groupMemberMids:
                    notInGroup.append(titan3Mid)
                if titan2Mid not in groupMemberMids:
                    notInGroup.append(titan2Mid)
                if titan1Mid not in groupMemberMids:
                    notInGroup.append(titan1Mid)
                if notInGroup != []:
                    client.inviteIntoGroup(group.id, notInGroup)
                else:
                    titan1.sendMessage(group.id, "Already in group.")
                    titan2.sendMessage(group.id, "Already in group.")
                    titan3.sendMessage(group.id, "Already in group.")
                    titan4.sendMessage(group.id, "Already in group.")
                    return titan5.sendMessage(group.id, "Already in group.")
                if titan3Mid not in groupMemberMids:
                    titan3.acceptGroupInvitation(group.id)
                if titan2Mid not in groupMemberMids:
                    titan2.acceptGroupInvitation(group.id)
                if titan1Mid not in groupMemberMids:
                    titan1.acceptGroupInvitation(group.id)
                if titan5Mid not in groupMemberMids:
                    titan5.acceptGroupInvitation(group.id)
                if titan4Mid not in groupMemberMids:
                    titan4.acceptGroupInvitation(group.id)
            elif msg.text.lower() == "/pset":
                if msg.toType == 0: return client.sendMessage(msg.to, 'คำสั่งนี้ใช้ได้เฉพาะในกลุ่มเท่านั้น')
                if "pinv" not in titan:
                    titan["pinv"] = {}
                if "pkick" not in titan:
                    titan["pkick"] = {}
                rt = "การป้องกันของกลุ่มนี้"
                if msg.to in titan["pinv"]: rt += "\nป้องกันเชิญ: เปิด"
                else: rt += "\nป้องกันเชิญ: ปิด"
                if msg.to in titan["pkick"]: rt += "\nป้องกันเตะ: เปิด"
                else: rt += "\nป้องกันเตะ: ปิด"
                client.sendMessage(msg.to, rt)
            elif msg.text.lower().startswith("/pinv"):
                if msg.toType == 0: return client.sendMessage(msg.to, 'คำสั่งนี้ใช้ได้เฉพาะในกลุ่มเท่านั้น')
                if "pinv" not in titan:
                    titan["pinv"] = {}
                try:
                    sT = msg.text.lower().split(" ")[1]
                except:
                    if msg.to in titan["pinv"]:
                        client.sendMessage(msg.to, "ป้องกันเตะเปิดอยู่\n\n/pkick off เพื่อปิด")
                    else:
                        client.sendMessage(msg.to, "ป้องกันเตะปิดอยู่\n\n/pkick on เพื่อเปิด")
                    return
                if sT == "on":
                    if msg.to in titan["pinv"]:
                        client.sendMessage(msg.to, "เปิดอยู่แล้ว")
                    else:
                        titan["pinv"][msg.to] = True
                        msg.sendMessage(msg.to, "เปิดแล้ว")
                elif sT == "off":
                    if msg.to not in titan["pinv"]:
                        client.sendMessage(msg.to, "ปิดอยู่แล้ว")
                    else:
                        del titan["pinv"][msg.to]
                        client.sendMessage(msg.to, "ปิดแล้ว")
                else:
                    client.sendMessage(msg.to, "ไม่พบคำสั่ง")
            elif msg.text.lower().startswith("/pkick"):
                if msg.toType == 0: return client.sendMessage(msg.to, 'คำสั่งนี้ใช้ได้เฉพาะในกลุ่มเท่านั้น')
                if "pkick" not in titan:
                    titan["pkick"] = {}
                try:
                    sT = msg.text.lower().split(" ")[1]
                except:
                    if msg.to in titan["pkick"]:
                        client.sendMessage(msg.to, "ป้องกันเตะเปิดอยู่\n\n/pkick off เพื่อปิด")
                    else:
                        client.sendMessage(msg.to, "ป้องกันเตะปิดอยู่\n\n/pkick oon เพื่อเปิด")
                    return
                if sT == "on":
                    if msg.to in titan["pkick"]:
                        client.sendMessage(msg.to, "เปิดอยู่แล้ว")
                    else:
                        titan["pkick"][msg.to] = True
                        client.sendMessage(msg.to, "เปิดแล้ว")
                elif sT == "off":
                    if msg.to not in titan["pkick"]:
                        client.sendMessage(msg.to, "ปิดอยู่แล้ว")
                    else:
                        del titan["pkick"][msg.to]
                        client.sendMessage(msg.to, "ปิดแล้ว")
                else:
                    client.sendMessage(msg.to, "ไม่พบคำสั่ง")
    except Exception as Error:
        print(Error)

while __name__ == "__main__":
    ops = Poll.singleTrace(count=50)
    if ops != None:
        for op in ops:
            try:
                titanBot(op)
            except KeyboardInterrupt:
                sys.exit()
            Poll.setRevision(op.revision)
